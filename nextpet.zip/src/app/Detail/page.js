import Slider from '@/src/components/Slider'
import React from 'react'

function page() {
  return (
    <div>
      Detals page of this home screen

      <Slider/>
    </div>
  )
}

export default page
