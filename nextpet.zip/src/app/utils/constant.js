const BASE_URL = "https://frontend.nextpetapp.com";
export default BASE_URL;
