const routes = {
    breeder_sign_in: '/breeder/sign-in',
    breeder_sign_up: '/breeder/sign-up',
    breeder_logout: '/breeder/logout',
    breeder_varification_code: '/breeder/varification-code',
    breeder_forget_password: '/breeder/forget-password',
    breeder_forget_password_varificatin_code: '/breeder/forget-password/otp_varification',
    breeder_profile:'/breeder/breeder-profile',
    breeder_leads:'/breeder/leads',
    breeder_subscription:'/breeder/subscription',
    breeder_posts:'/breeder/posts',
    breeder_favorites:'/breeder/favorites',

  };
  
  export default routes;